from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import uvicorn
from datetime import datetime
from pydantic import BaseModel, conlist
from fastapi.responses import JSONResponse
from PIL import Image
from deepface import DeepFace
import numpy as np
import cv2
import numpy as np
import tensorflow as tf
import os
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
from typing import List

app = FastAPI()
origins = [
    "http://localhost:3000",
    "http://localhost:3001"
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOADS_DIR = "./uploads"

Path(UPLOADS_DIR).mkdir(parents=True, exist_ok=True)

initial_data = np.zeros((1, 26))  # Example initial data with appropriate shape
scaler = MinMaxScaler().fit(initial_data)

# Load model
pose_model = tf.keras.models.load_model('model.h5')

def getEmotionFromImage(image_file):
    # Construct full path to the image file
    image_path = os.path.join(UPLOADS_DIR, image_file)
    
    # Check if the file exists
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file '{image_path}' not found")

    # Read the image
    image = cv2.imread(image_path)
    
    # Check if the image was loaded successfully
    if image is None:
        raise ValueError(f"Failed to load image file '{image_path}'")

    # Analyze the image for emotions
    result = DeepFace.analyze(image, actions=['emotion'])
    
    # Extract the dominant emotion
    dominant_emotion = result[0]['dominant_emotion']
    
    return dominant_emotion

@app.post("/predict-emotion")
async def upload_image(file: UploadFile = File(...)):
    try:
        # Ensure the uploads directory exists
        if not os.path.exists(UPLOADS_DIR):
            os.makedirs(UPLOADS_DIR)
        
        # Save the uploaded file
        file_path = os.path.join(UPLOADS_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        # Get emotion from the uploaded image
        emotion = getEmotionFromImage(file.filename)
        
        return {"emotion": emotion}
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

def predict_pose(image_path):
  # Load and preprocess the image
  image = Image.open(image_path)
  image = image.resize((224, 224))  # Resize to match the input shape expected by the model
  image = np.array(image) / 255.0  # Normalize pixel values

  # Reshape instead of flatten (fix for shape mismatch)
  image = image.reshape(1, 224, 224, 3)  # Assuming model expects RGB image with 3 channels

  # Predict pose
  pose_prediction = pose_model.predict(image)

  # Process the prediction and return the result
  # You can customize this based on your model's output and requirements
  # pose_result = process_pose_prediction(pose_prediction)

  return pose_prediction

@app.post("/predict-pose")
async def upload_image(file: UploadFile = File(...)):
    try:
        # Ensure the uploads directory exists
        if not os.path.exists(UPLOADS_DIR):
            os.makedirs(UPLOADS_DIR)
        
        # Save the uploaded file
        file_path = os.path.join(UPLOADS_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        # Get pose prediction from the uploaded image
        pose_result = predict_pose(file_path)
        
        return {"pose_result": pose_result}
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

# ADHD Screening
model = load_model('adhd_model.h5')

classes = {0: 'Focus Problems', 1: 'Impulsive Problems', 2: 'Neither', 3: 'Equal'}

class UserRecord(BaseModel):
    user_record: conlist(int, min_items=26, max_items=26)  # Constrain length to 26

# Define a function for making predictions
def predict_adhd_problem(user_record, scaler):
    # Preprocess user input
    xnew = np.array([user_record])
    
    # Fit the scaler if not already fitted
    if not hasattr(scaler, 'data_max_'):
        scaler.fit(np.array(user_record).reshape(1, -1))  # Fit scaler on the data
    
    # Scale the input data
    xnew_scaled = scaler.transform(xnew)
    
    # Make prediction
    ynew = model.predict(xnew_scaled)
    predicted_label = np.argmax(ynew)

    # Get predicted problem
    predicted_problem = classes[predicted_label]

    # Perform additional checks as needed
    focus_sum = sum(user_record[:9])
    impulsive_sum = sum(user_record[18:])
    ood_check = sum(user_record[26:]) <= 8

    if focus_sum == 0 and impulsive_sum == 0:
        return "Neither", ood_check
    elif impulsive_sum == focus_sum:
        return "Equal", ood_check
    elif focus_sum <= 9:
        return "No Focus Problems", ood_check
    elif impulsive_sum <= 9:
        return "No Impulsive Problems", ood_check
    else:
        return predicted_problem, ood_check

@app.post('/predict')
async def predict(user_record: UserRecord):
    try:
        predicted_problem, has_ood = predict_adhd_problem(user_record.user_record, scaler)
        return {
            'predicted_problem': predicted_problem,
            'has_ood': has_ood
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port="8000")
